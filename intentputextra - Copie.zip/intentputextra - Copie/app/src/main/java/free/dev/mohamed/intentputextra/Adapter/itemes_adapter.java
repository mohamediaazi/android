package free.dev.mohamed.intentputextra.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import free.dev.mohamed.intentputextra.R;
import free.dev.mohamed.intentputextra.models.itemes;
import free.dev.mohamed.intentputextra.second_class;

public class itemes_adapter extends RecyclerView.Adapter<itemes_adapter.viewholder> {
    Context context;
    List<itemes>mitemes;

    public itemes_adapter(Context context, List<itemes> mitemes) {
        this.context = context;
        this.mitemes = mitemes;
    }

    @Override
    public viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.itemes,parent,false);
        viewholder viewholder= new viewholder(view);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(final viewholder holder, final int position) {
        Glide.with(context).load(mitemes.get(position).getImage()).asBitmap().into(holder.image);
        holder.title.setText(mitemes.get(position).getTitle());
        holder.name.setText(mitemes.get(position).getName());
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // you ca use v to pass the context or just write context
                Intent intent=new Intent(context,second_class.class);
                intent.putExtra("image",mitemes.get(position).getImage());
                intent.putExtra("name",mitemes.get(position).getName());
                intent.putExtra("title",mitemes.get(position).getTitle());
                context.startActivities(new Intent[]{intent});

            }
        });


    }

    @Override
    public int getItemCount() {
        return mitemes.size();
    }

    public  class viewholder extends RecyclerView.ViewHolder{
        ImageView image;
        TextView title,name;
        LinearLayout linearLayout;

        public viewholder(View itemView) {
            super(itemView);
linearLayout=itemView.findViewById(R.id.linner);
            image=itemView.findViewById(R.id.profile);
            title=itemView.findViewById(R.id.title);
            name=itemView.findViewById(R.id.name);

        }
    }

}
