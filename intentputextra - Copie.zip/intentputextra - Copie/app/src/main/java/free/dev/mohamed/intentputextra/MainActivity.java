package free.dev.mohamed.intentputextra;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import free.dev.mohamed.intentputextra.Adapter.itemes_adapter;
import free.dev.mohamed.intentputextra.models.itemes;

public class MainActivity extends AppCompatActivity {
 RecyclerView recyclerView;
    List<itemes> mdtalist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        mdtalist=new ArrayList<>();
        mdtalist.add(new itemes("name 1 ","1","https://i.ibb.co/nCxMD5p/adapter.png"));
        mdtalist.add(new itemes("name2 ","2","https://i.ibb.co/nCxMD5p/adapter.png"));
        mdtalist.add(new itemes("name3 ","3","https://i.ibb.co/NnZmxXc/apk.png"));
        mdtalist.add(new itemes("name4 ","4","https://i.ibb.co/Xk1Hmjz/Capture.png"));
        mdtalist.add(new itemes("name5 ","5","https://i.ibb.co/CVwVh3L/exemple-json.png"));
        mdtalist.add(new itemes("name6","6","https://i.ibb.co/kHnnzRR/he.png"));
        mdtalist.add(new itemes("name7 ","7","https://i.ibb.co/Cv5Smrp/photoshope-2.jpg"));
        mdtalist.add(new itemes("name8 ","8","https://i.ibb.co/Kq0y6hS/user-json-exemple.png"));
        mdtalist.add(new itemes("name9 ","9","https://i.ibb.co/Kq0y6hS/user-json-exemple.png"));






//ibb.co/PQqG5fk][img]https://i.ibb.co/nCxMD5p/adapter.png[/img][/url]
//imgbb.com/][img]https://i.ibb.co/NnZmxXc/apk.png[/img][/url]
//ibb.co/jZmt7bL][img]https://i.ibb.co/Xk1Hmjz/Capture.png[/img][/url]
//ibb.co/zSJsbzT][img]https://i.ibb.co/hKfsHSJ/Capture1.png[/img][/url]
//ibb.co/3STSB9K][img]https://i.ibb.co/CVwVh3L/exemple-json.png[/img][/url]
//ibb.co/mDssdLL][img]https://i.ibb.co/kHnnzRR/he.png[/img][/url]
//imgbb.com/][img]https://i.ibb.co/YfsFvjq/is.jpg[/img][/url]
//ibb.co/NSwpwtj][img]https://i.ibb.co/cLztzkF/photoshop.jpg[/img][/url]
//imgbb.com/][img]https://i.ibb.co/Cv5Smrp/photoshope-2.jpg[/img][/url]
//ibb.co/WyxKn5j][img]https://i.ibb.co/Kq0y6hS/user-json-exemple.png[/img][/url]



       itemes_adapter adapter=new itemes_adapter(getApplicationContext(),mdtalist);
        recyclerView.setAdapter(adapter);

    }
}
