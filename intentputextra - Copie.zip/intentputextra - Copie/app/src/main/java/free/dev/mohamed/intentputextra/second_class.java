package free.dev.mohamed.intentputextra;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class second_class extends AppCompatActivity {

    @Override
    protected  void onCreate(Bundle SavadInstanceState){
        super.onCreate(SavadInstanceState);
        setContentView(R.layout.second);
        getintent();



    }
    private  void getintent(){
        if(getIntent().hasExtra("image")&&getIntent().hasExtra("title")&&getIntent().hasExtra("name")){
            String image=getIntent().getStringExtra("image");
            String title=getIntent().getStringExtra("image");
            String name=getIntent().getStringExtra("name");

            setintent(image,title,name);

        }
    }
    private void setintent(String image,String title,String name){
        TextView mtitle=findViewById(R.id.title2);
        ImageView mimage=findViewById(R.id.profile2);
        TextView mname=findViewById(R.id.name2);
        mtitle.setText(title);
        Glide.with(getApplicationContext()).load(image).asBitmap().error(R.drawable.ic_launcher_background).into(mimage);
        mname.setText(name);
    }



}
